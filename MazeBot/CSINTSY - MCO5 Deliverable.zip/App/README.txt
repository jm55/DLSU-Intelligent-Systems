MazeBot.exe
====================================
Written in Python
Cruzada, Escalona, Francisco, Loyola
====================================

1. Please don't delete maze.txt as it is a default maze used by the program if no custom file was given.

2. Custom maze files can be used using relative path (from the same level) or absolute path of the file.