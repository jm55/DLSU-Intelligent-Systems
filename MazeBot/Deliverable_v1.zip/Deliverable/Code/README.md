# MazeBot
## Code Structure
1. **driver.py** - For launching the application.
2. **file.py** - For handling file related tasks.
3. **utils.py** - For non-critical yet helpful functions.