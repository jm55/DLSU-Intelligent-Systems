## Chatbot
CSINTSY MCO-5
Cruzada, Escalona, Francisco, Loyola.

## Description
The goal of the project is to showcase how the different classification models:

1. K-Nearest Neighbor Classifier
2. Decision Tree Classifier
3. Logistic Regression

are able to predict what crops will be produced given the different levels of nitrogen, phosphorus, and potassium in the soil, temperature, humidity, pH, and rainfall?


The project is to implemented using Jupyter Notebook for the executions of the different classification models, computations, and visualizations.

## Execution
1. Run Jupyter Notebook
2. Upload the file "MCO3_Group5_notebook.ipnyb" to Jupyter Notebook.
3. Upload the file "crops_dataset.csv" to Jupyter Notebook.
4. Open the "MCO3_Group5_notebook.ipnyb" file.
5. For each cell in the notebook that is not a header, click the "Run" button on the top menu or press the Shift+Enter keys.

Kindly take note that some parts of the code take a while to generate the output.