## Chatbot
CSINTSY MCO-5
Cruzada, Escalona, Francisco, Loyola.

## Description
The goal of the project is to create a simple medical diagnosis chatbot which could be used as an interim solution for rural clinics in the Philippines.

The chatbot is to be implemented using Prolog with the guiding design and intelligence principles presented by logic-based models of AI.

## Execution
1. Open SWI Prolog 
2. Go to the directory where the Chatbot file is located.
3. Start the application by entering the command: 
	consult('<working directory of the chatbot file>') 

	or if in the same directory, type:
	
	['chatbot'].

4. Enter the command "checkup." to start the program.

5. For the patient's personal data, kindly enter a string input for the name and a numerical value for the other data.

6. When prompt with a "Yes" or "No" question, kindly enter "y." for Yes and "n." for No.